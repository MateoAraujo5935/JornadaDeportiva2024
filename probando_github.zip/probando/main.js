document.addEventListener('DOMContentLoaded', () => {
    function createElement(elementData) {
        const newElement = document.createElement(elementData.etiqueta);

        if (elementData.class) newElement.className = elementData.class;
        if (elementData.id) newElement.id = elementData.id;
        if (elementData.style) newElement.style.cssText = elementData.style;

        if (elementData.etiqueta === 'img') {
            if (elementData.src) newElement.src = elementData.src;
            if (elementData.alt) newElement.alt = elementData.alt;
        } else if (elementData.etiqueta === 'p' && elementData.text) {
            newElement.textContent = elementData.text;
        }

        if (elementData.children) {
            elementData.children.forEach(childData => {
                const childElement = createElement(childData);
                newElement.appendChild(childElement);
            });
        }

        return newElement;
    }

    function loadContent(page) {
        fetch('contenido.json')
            .then(response => response.json())
            .then(data => {
                const pageContent = data[page];
                if (!pageContent) {
                    console.error('No content found for page:', page);
                    return;
                }

                const container = document.querySelector('main');
                container.innerHTML = ''; // Limpiar contenido previo

                pageContent.forEach(elementData => {
                    const newElement = createElement(elementData);
                    container.appendChild(newElement);
                });

                console.log('Content loaded successfully for page:', page);
            })
            .catch(error => console.error('Error loading content:', error));
    }

    document.querySelectorAll('header .nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();

            const page = e.target.textContent.trim().toLowerCase();
            console.log('Page selected:', page);

            loadContent(page);
        });
    });

    // Cargar contenido inicial
    loadContent('main');
});

