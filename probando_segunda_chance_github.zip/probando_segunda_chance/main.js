document.addEventListener('DOMContentLoaded', () => {
    // Variable para almacenar los datos del JSON
    let jsonData = {};

    // Cargar el JSON
    fetch('contenido.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            jsonData = data;
            console.log('Datos JSON cargados:', jsonData);
            // Mostrar el contenido MAIN por defecto
            displayContent('MAIN');
        })
        .catch(error => console.error('Error al cargar el JSON:', error));

    // Función para mostrar contenido en base al tipo de sección
    function displayContent(section) {
        const mainContent = document.getElementById('main-content');

        // Limpia el contenido actual de main
        mainContent.innerHTML = '';

        // Verifica que la sección existe en los datos
        if (jsonData[section]) {
            jsonData[section].forEach(item => {
                // Crea un nuevo elemento basado en los datos del JSON
                const element = document.createElement(item.etiqueta);

                if (item.class) {
                    element.className = item.class;
                }
                if (item.id) {
                    element.id = item.id;
                }
                if (item.style) {
                    element.style.cssText = item.style;
                }
                element.textContent = item.contenido;

                // Agrega el nuevo elemento al contenedor correspondiente
                mainContent.appendChild(element);
            });
        } else {
            console.error(`La sección ${section} no se encuentra en el JSON.`);
        }
    }

    // Configura los event listeners para las imágenes del carrusel
    document.querySelectorAll('.carousel-item img').forEach(img => {
        img.addEventListener('click', () => {
            const target = img.parentElement.getAttribute('data-target');
            displayContent(target);
        });
    });
});
